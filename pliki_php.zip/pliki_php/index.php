<!DOCTYPE html>
<html>
<head>
    <title>Moje pliki</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>

<?php

echo "<h1>MOJE PLIKI</h1>";

echo "Aktualny katalog: " . getcwd();

$katalog = "dokumenty";

$pliki = scandir($katalog);

echo "<h2>ZAWARTOŚĆ KATALOGU</h2>";

echo "<table>";

echo "<tr>";
echo "<th>Nazwa</th>";
echo "<th>Typ</th>";
echo "<th>Rozmiar</th>";
echo "</tr>";

foreach ($pliki as $plik) {

    if ($plik != "." && $plik != "..") {

        echo "<tr>";

        echo "<td>" . $plik . "</td>";

        if (is_file($katalog . "/" . $plik)) {
            echo "<td>PLIK</td>";
            echo "<td>" . filesize($katalog . "/" . $plik) . " B</td>";
        }

        if (is_dir($katalog . "/" . $plik)) {
            echo "<td>KATALOG</td>";
            echo "<td>-</td>";
        }

        echo "</tr>";
    }
}

echo "</table>";

?>

</body>
</html>
